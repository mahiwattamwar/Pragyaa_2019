A Pen created at CodePen.io. You can find this one at https://codepen.io/chrisfrees/pen/AzsID.

 Just a simple blog featuring the material design style.